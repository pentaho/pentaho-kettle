# Place keytab in here.
# Naming for keytab should be <principal name>.keytab
# for example admin.keytab